#!/usr/bin/env python
import struct
import numpy as np

fn = "./coulomb_full_iq_1.dat"
with open(fn, "rb") as h:
    bindata = h.read()

i8 = ("l", 8)
i4 = ("i", 4)
db = ("d", 8)

start, end = 0, 4 * i4[1]
marker, iq, naux, is_complex = struct.unpack(4 * i4[0], bindata[start:end])

ndata = naux * (naux + 1) // 2
if is_complex == 0:
    # real case
    print("real")
    start, end = end, end + ndata * db[1]
    data = np.array(struct.unpack(ndata * db[0], bindata[start:end]))
else:
    print("cplx")
    start, end = end, end + ndata * db[1] * 2
    data = np.array(struct.unpack(ndata * db[0] * 2, bindata[start:end]))
    data = data[::2] + 1.0j * data[1::2]

print(data[:10])
print(data[104:114])
print(data[207:217])
