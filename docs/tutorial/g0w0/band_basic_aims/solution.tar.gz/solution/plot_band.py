#!/usr/bin/env python3
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
import numpy as np

N_HIGHEST_BANDS_TO_EXCLUDE = 5


def read_band(path):
    data = np.loadtxt(path)
    return data[:, 1:4], data[:, 4::2], data[:, 5::2]


def reciprocal_lattice(path):
    vectors = []
    for line in path.read_text().splitlines():
        fields = line.split()
        if fields and fields[0] == "lattice_vector":
            vectors.append([float(value) for value in fields[1:4]])
    return 2 * np.pi * np.linalg.inv(np.array(vectors)).T


def path_coordinate(kpoints, reciprocal):
    cartesian = kpoints @ reciprocal
    steps = np.linalg.norm(np.diff(cartesian, axis=0), axis=1)
    return np.concatenate(([0.0], np.cumsum(steps)))


def plot_bands(ax, x, occupations, energies, label, **style):
    vbm = energies[occupations > 0.0].max()
    for iband, band in enumerate(energies.T[:-N_HIGHEST_BANDS_TO_EXCLUDE]):
        ax.plot(x, band - vbm, label=label if iband == 0 else None, **style)


def main():
    root = Path(__file__).resolve().parent
    kpoints, occupations, ks_energies = read_band(root / "KS_band_spin_1.dat")
    gw_kpoints, gw_occupations, gw_energies = read_band(root / "GW_band_spin_1.dat")
    if not np.allclose(kpoints, gw_kpoints):
        raise ValueError("KS and GW files use different band paths")
    if ks_energies.shape != gw_energies.shape:
        raise ValueError("KS and GW files contain different numbers of bands")
    if ks_energies.shape[1] <= N_HIGHEST_BANDS_TO_EXCLUDE:
        raise ValueError("not enough bands remain after excluding high bands")

    x = path_coordinate(kpoints, reciprocal_lattice(root / "geometry.in"))
    gamma = np.flatnonzero(np.all(np.isclose(kpoints, 0.0), axis=1))[0]

    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", *plt.rcParams["font.serif"]],
        "font.size": 16,
        "mathtext.fontset": "cm",
        "xtick.direction": "in",
        "ytick.direction": "in",
        "legend.frameon": True,
        "legend.fancybox": True,
        "legend.framealpha": 1.0,
        "savefig.dpi": 300,
        "savefig.transparent": False,
        "xtick.major.size": plt.rcParams["xtick.major.size"] * 1.5,
        "xtick.minor.size": plt.rcParams["xtick.minor.size"] * 1.5,
        "xtick.major.width": plt.rcParams["xtick.major.width"] * 1.5,
        "xtick.minor.width": plt.rcParams["xtick.minor.width"] * 1.5,
        "ytick.major.size": plt.rcParams["ytick.major.size"] * 1.5,
        "ytick.minor.size": plt.rcParams["ytick.minor.size"] * 1.5,
        "ytick.major.width": plt.rcParams["ytick.major.width"] * 1.5,
        "ytick.minor.width": plt.rcParams["ytick.minor.width"] * 1.5,
        "axes.linewidth": plt.rcParams["axes.linewidth"] * 1.5,
    })
    fig, ax = plt.subplots(figsize=(7, 6))
    plot_bands(ax, x, occupations, ks_energies, "PBE", color="black", linestyle="--")
    plot_bands(ax, x, gw_occupations, gw_energies, r"$G^0W^0$@PBE", color=(0.8, 0, 0))

    ax.set_xlim(x[0], x[-1])
    ax.set_ylim(-10, 16)
    ax.set_ylabel("Energy [eV]", fontsize=18)
    ax.set_xticks([x[0], x[gamma], x[-1]], ["L", r"$\Gamma$", "X"])
    ax.axhline(0.0, color="black", linestyle=":")
    ax.xaxis.grid(color="black")
    ax.set_axisbelow(True)
    ax.yaxis.set_minor_locator(MultipleLocator(1))
    ax.legend()
    fig.savefig(root / "band.svg", bbox_inches="tight", pad_inches=0.1)


if __name__ == "__main__":
    main()
